import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000", {
  reconnection: true,
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
});

function App() {

  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [status, setStatus] = useState("Disconnected");

  useEffect(() => {

    socket.on("connect", () => {
      setStatus("Connected");
      console.log("Connected to server");
    });

    socket.on("disconnect", () => {
      setStatus("Disconnected");
      console.log("Disconnected");
    });

    socket.on("message", (data) => {
      setMessages((prev) => [...prev, data]);
    });

    return () => {
      socket.off("message");
    };

  }, []);

  const sendMessage = () => {

    if (message.trim() !== "") {

     socket.emit("message", {
  text: message,
  time: new Date().toLocaleTimeString(),
});

      setMessage("");
    }
  };

  return (
    <div style={{ padding: "20px" }}>

      <h1>WebSocket Communication</h1>

      <h3>Status: {status}</h3>

      <input
        type="text"
        placeholder="Enter message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />

      <button onClick={sendMessage}>
        Send
      </button>

      <div style={{ marginTop: "20px" }}>

        <h2>Messages</h2>

        {messages.map((msg, index) => (
  <div key={index}>
    <p>
      <strong>{msg.time}</strong> : {msg.text}
    </p>
  </div>
))}
      </div>

    </div>
  );
}

export default App;